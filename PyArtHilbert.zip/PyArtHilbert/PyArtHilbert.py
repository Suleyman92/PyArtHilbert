from math import pow
import pygame

def GetPoint(index, length=1, level=1, offset=False):
    points = [
        [0, 0],
        [0, 1],
        [1, 1],
        [1, 0]
    ]
    i = index & 3
    point = points[i].copy()

    for x in range(1, level):
        val = pow(2, x)

        index = index >> 2
        i = index & 3

        if i == 0:
            point[0], point[1] = point[1], point[0]

        elif i == 1:
            point[1] += val

        elif i == 2:
            point[0] += val
            point[1] += val

        elif i == 3:
            point[0], point[1] = val - 1 - point[1], val - 1 - point[0]
            point[0] += val

    point = [
        point[0] * length,
        point[1] * length
    ]

    if offset:
        point = [
            point[0] + length / 2,
            point[1] + length / 2
        ]

    return point


Width, Height = 1000, 1000
Resolution = (Width, Height)

pygame.init()
window = pygame.display.set_mode(Resolution)
clock = pygame.time.Clock()
fps = 30

Black, White = (0, 0, 0), (255, 255, 255)

s = 6
n = int(pow(2, s))
t = n * n

lineThicknes = 2

Hilbert = [None for i in range(t)]

for i in range(t):
    length = Width / n
    Hilbert[i] = GetPoint(i, length, s, True)

toggle_color = False

timer = 1
increment_speed = 1

run = True
while run:
    window.fill((Black))
    clock.tick(fps)
    frame_rate = int(clock.get_fps())
    pygame.display.set_caption("Hilter curve - FPS : {}".format(frame_rate))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.type == pygame.K_ESCAPE:
                run = False
            if event.key == pygame.K_r:
                timer = 1
            if event.key == pygame.K_ESCAPE:
                toggle_color = not toggle_color

    for i in range(timer - 1):
        c = pygame.Color(0, 0, 0)
        c.hsva = (i / 10 % 360, 100, 100, 100)
        color = White if toggle_color else  c
        pygame.draw.line(window, color, Hilbert[i], Hilbert[i + 1], lineThicknes)

    pygame.display.flip()

    timer += increment_speed
    if timer > t:
        timer = t

pygame.quit()

